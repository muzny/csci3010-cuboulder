#include <iostream>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QDebug>

#include "plotwindow.h"
#include "ui_plotwindow.h"
#include "point.h"

// Names:
//
//

int PlotWindow::random_clicks_ = 0;

PlotWindow::PlotWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PlotWindow)
{
    // we need to set up the ui before we draw on our scene
    ui->setupUi(this);


    QGraphicsView * view = ui->plotGraphicsView;

    // scene is a pointer field of plot window
    scene = new QGraphicsScene;



    view->setScene(scene);
    view->setSceneRect(0,0,view->frameSize().width(),view->frameSize().height());

    // so that you have random available and properly seeded
    srand(time(0));


    qDebug() << "Here's an example debugging statement";

    // Day 1, Task 2, number 5:
    // use the scene->addLine method to add lines to your scene for the x and y axes.
    // you may find the view->frameSize.[width()|height()] methods helpful as well.
    // scene->addLine(x1, y1, x2, y2);

    // y axis
    scene->addLine(view->frameSize().width() / 2, 0, view->frameSize().width() / 2, view->frameSize().height());
    // x axis
    scene->addLine(0, view->frameSize().height() / 2, view->frameSize().width(), view->frameSize().height() / 2);


    // Day 1, Task 4, number 2:
    // connect the random button's &QAbstractButton::pressed event to the PlotWindow's new slot
    // connect(sender, sender signal, receiver, receiver slot)
    connect(ui->randomButton, &QAbstractButton::pressed,
            this, &PlotWindow::TestSlot);


    // Day 2, Task 3
    // Adding a point "manually" at the origin
    QColor color(50, 0, 255);
    Point * p = new Point(color,
                          10,
                          50);
//    Point * p = new Point(color,
//                          view->frameSize().width() / 2 - (p->get_width() / 2),
//                          view->frameSize().height() / 2 - (p->get_width() / 2));
    scene->addItem(p);
    connect(p, &Point::PointClicked, this, &PlotWindow::PointClickedSlot);
    connect(p, &Point::PointClickedDeleteMode, this, &PlotWindow::PointClickedDeleteModeSlot);

}

void PlotWindow::TestSlot() {
    qDebug() << "test pressed";

}

PlotWindow::~PlotWindow()
{
    delete ui;
}

void PlotWindow::on_randomButton_clicked()
{
    qDebug() << "random clicked";
    random_clicks_++;
    std::string text = std::to_string(random_clicks_);
    ui->randomButton->setText(QString(text.c_str()));

    // if your window is only updating if you resize it, you need to add
//    this->repaint();
}


// Day 2, Task 4
// Adding a point whenever the add point button is clicke
void PlotWindow::on_addButton_clicked()
{

    bool safe = false;
    int x = ui->xCoord->text().toInt(&safe);
    if (!safe) {
        return;
    }
    int y = ui->yCoord->text().toInt(&safe);
    if (!safe) {
        return;
    }
    QColor color(255, 255, 255);
    int x_adj = x + (ui->plotGraphicsView->frameSize().width() / 2) - (Point::get_width() / 2);
    int y_adj = (-1 * y + (ui->plotGraphicsView->frameSize().height() / 2) - (Point::get_width() / 2));
    Point *item = new Point(color, x_adj, y_adj);
    scene->addItem(item);

    // Day 2, Task 5
    // connection part
    connect(item, &Point::PointClicked, this, &PlotWindow::PointClickedSlot);
    connect(item, &Point::PointClickedDeleteMode, this, &PlotWindow::PointClickedDeleteModeSlot);

}

// Day 2, Task 5
// slot part
void PlotWindow::PointClickedSlot(int x, int y) {
    qDebug() << x;
    qDebug() << y;
}

// day 3 - switch mode
void PlotWindow::on_deletePoints_clicked()
{
    qDebug() << "delete clicked";
    qDebug() << Point::delete_mode_;
    Point::delete_mode_ = !Point::delete_mode_;
    if (Point::delete_mode_) {
        ui->centralWidget->setCursor(Qt::CrossCursor);
    } else {
        ui->centralWidget->setCursor(Qt::ArrowCursor);
    }
}

// day 3 - delete point slot
void PlotWindow::PointClickedDeleteModeSlot(Point * p) {
    qDebug() << "plot window a point in delete mode clicked";
    ui->plotGraphicsView->scene()->removeItem(p);
}
