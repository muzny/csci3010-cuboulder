#include <iostream>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QDebug>

#include "plotwindow.h"
#include "ui_plotwindow.h"

// Names:
//
//

PlotWindow::PlotWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PlotWindow)
{
    // scene is a pointer field of plot window
    scene = new QGraphicsScene;

    // we need to set up the ui before we draw on our scene
    ui->setupUi(this);
    QGraphicsView * view = ui->plotGraphicsView;
    view->setScene(scene);
    view->setSceneRect(0,0,view->frameSize().width(),view->frameSize().height());


    // Task 2, number 5:
    // use the scene->addLine method to add lines to your scene for the x and y axes.
    // you may find the view->frameSize.[width()|height()] methods helpful as well.




    // Task 4, number 2:
    // connect the random button's &QAbstractButton::pressed event to the PlotWindow's new slot
}

PlotWindow::~PlotWindow()
{
    delete ui;
}
